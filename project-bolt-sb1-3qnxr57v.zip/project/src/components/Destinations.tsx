import Destination from './Destination';

const destinations = [
  {
    title: 'Maldives Paradise',
    description: 'Experience luxury overwater villas and pristine beaches in the heart of the Indian Ocean.',
    imageUrl: 'https://images.unsplash.com/photo-1514282401047-d79a71a590e8?auto=format&fit=crop&q=80',
    price: '$4,999'
  },
  {
    title: 'Swiss Alps Adventure',
    description: 'Discover the magic of the Swiss Alps with exclusive ski experiences and luxury chalets.',
    imageUrl: 'https://images.unsplash.com/photo-1531310197839-ccf54634509e?auto=format&fit=crop&q=80',
    price: '$5,999'
  },
  {
    title: 'Amalfi Coast Elegance',
    description: 'Indulge in the Mediterranean charm with private yacht tours and exquisite dining.',
    imageUrl: 'https://images.unsplash.com/photo-1533104816931-20fa691ff6ca?auto=format&fit=crop&q=80',
    price: '$6,499'
  },
  {
    title: 'Dubai Extravaganza',
    description: 'Experience the height of luxury in the city of gold with exclusive desert adventures.',
    imageUrl: 'https://images.unsplash.com/photo-1512453979798-5ea266f8880c?auto=format&fit=crop&q=80',
    price: '$7,999'
  },
  {
    title: 'Santorini Retreat',
    description: 'Unwind in private villas overlooking the Aegean Sea with personalized experiences.',
    imageUrl: 'https://images.unsplash.com/photo-1613395877344-13d4a8e0d49e?auto=format&fit=crop&q=80',
    price: '$5,499'
  },
  {
    title: 'Bali Serenity',
    description: 'Discover spiritual wellness and luxury in the heart of Indonesian paradise.',
    imageUrl: 'https://images.unsplash.com/photo-1537996194471-e657df975ab4?auto=format&fit=crop&q=80',
    price: '$4,499'
  }
];

export default function Destinations() {
  return (
    <section id="destinations" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Exclusive Destinations</h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Discover our carefully curated collection of the world's most luxurious destinations
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {destinations.map((destination, index) => (
            <Destination key={index} {...destination} />
          ))}
        </div>
      </div>
    </section>
  );
}