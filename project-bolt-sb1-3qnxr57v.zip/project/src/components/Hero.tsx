export default function Hero() {
  return (
    <section id="home" className="relative h-screen flex items-center justify-center">
      <div 
        className="absolute inset-0 bg-cover bg-center z-0"
        style={{
          backgroundImage: 'url("https://images.unsplash.com/photo-1502680390469-be75c86b636f?auto=format&fit=crop&q=80")',
        }}
      >
        <div className="absolute inset-0 bg-black/50 z-10"></div>
      </div>
      
      <div className="relative z-20 text-center text-white px-4">
        <h1 className="text-5xl md:text-6xl font-bold mb-6">
          Luxury Travel Awaits You
        </h1>
        <p className="text-xl md:text-2xl mb-8 max-w-2xl mx-auto">
          Experience the world's most exclusive destinations with personalized luxury journeys
        </p>
        <a 
          href="#destinations" 
          className="inline-block bg-white text-gray-900 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors"
        >
          Explore Destinations
        </a>
      </div>
    </section>
  );
}