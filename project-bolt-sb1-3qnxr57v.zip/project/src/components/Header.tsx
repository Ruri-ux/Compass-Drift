import { Compass } from 'lucide-react';
import { useState } from 'react';

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="fixed w-full bg-white/90 backdrop-blur-sm z-50 shadow-sm">
      <nav className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <a href="#home" className="flex items-center space-x-2 text-2xl font-bold text-gray-900">
            <Compass className="h-8 w-8" />
            <span>Compass Drift</span>
          </a>
          
          <button
            className="lg:hidden"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={isMenuOpen ? "M6 18L18 6M6 6l12 12" : "M4 6h16M4 12h16M4 18h16"} />
            </svg>
          </button>

          <div className={`${isMenuOpen ? 'block' : 'hidden'} lg:block absolute lg:relative top-full left-0 w-full lg:w-auto bg-white lg:bg-transparent shadow-lg lg:shadow-none`}>
            <ul className="flex flex-col lg:flex-row lg:items-center lg:space-x-8 p-4 lg:p-0">
              <li><a href="#home" className="block py-2 text-gray-700 hover:text-blue-600 transition-colors">Home</a></li>
              <li><a href="#destinations" className="block py-2 text-gray-700 hover:text-blue-600 transition-colors">Destinations</a></li>
              <li><a href="#private-consultation" className="block py-2 text-gray-700 hover:text-blue-600 transition-colors">Private Consultation</a></li>
              <li><a href="#book" className="block py-2 px-4 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">Book Now</a></li>
            </ul>
          </div>
        </div>
      </nav>
    </header>
  );
}