import { useEffect } from 'react';
import { loadScript } from "@paypal/paypal-js";

interface PayPalButtonProps {
  amount: number;
}

export default function PayPalButton({ amount }: PayPalButtonProps) {
  useEffect(() => {
    loadScript({ 
      "client-id": "test", // Replace with your PayPal client ID in production
      currency: "USD"
    })
    .then((paypal) => {
      if (paypal) {
        paypal
          .Buttons({
            createOrder: (data, actions) => {
              return actions.order.create({
                purchase_units: [
                  {
                    amount: {
                      value: amount.toString(),
                      currency_code: "USD"
                    },
                    description: "Private Travel Consultation"
                  }
                ]
              });
            },
            onApprove: async (data, actions) => {
              const order = await actions.order?.capture();
              console.log("Payment successful!", order);
              // Handle successful payment here
            },
            onError: (err) => {
              console.error("PayPal error:", err);
              // Handle error here
            }
          })
          .render("#paypal-button-container");
      }
    });
  }, [amount]);

  return <div id="paypal-button-container" className="mt-6"></div>;
}