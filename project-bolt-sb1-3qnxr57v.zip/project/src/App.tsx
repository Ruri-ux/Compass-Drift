import Header from './components/Header';
import Hero from './components/Hero';
import Destinations from './components/Destinations';
import BookingSection from './components/BookingSection';
import PrivateConsultation from './components/PrivateConsultation';
import AnnualContract from './components/AnnualContract';
import Footer from './components/Footer';

function App() {
  return (
    <div className="min-h-screen">
      <Header />
      <main>
        <Hero />
        <Destinations />
        <PrivateConsultation />
        <AnnualContract />
        <BookingSection />
      </main>
      <Footer />
    </div>
  );
}

export default App;